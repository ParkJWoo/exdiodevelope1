﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Loot")
        {
            print("We picked " + other.name);
            GameDB._instance.AddItem(other.GetComponent<Item>());
            Destroy(other.gameObject, 0.1f);
        }
    }
}
