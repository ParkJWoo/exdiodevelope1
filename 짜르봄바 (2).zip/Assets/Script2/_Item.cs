﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ItemType { Tool, Consumable};

public class _Item : MonoBehaviour {

    public ItemType type;
    public Sprite spriteNeutral;
    public Sprite spriteHighlighted;
    public int maxSize;                 //아이템을 겹칠 수 있는 최대횟수

	public void Use()
    {
        switch (type)
        {
            case ItemType.Tool:
                Debug.Log("I just used a tool");
                break;
            case ItemType.Consumable:
                Debug.Log("I just used a consumable");
                break;
        }
    }
}
