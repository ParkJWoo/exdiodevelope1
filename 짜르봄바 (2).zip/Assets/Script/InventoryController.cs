﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryController : MonoBehaviour {

    public Transform SelectedItem, SelectedSlot, OriginalSlot;
    public GameObject SlotPrefab, ItemPrefab;
    public Vector2 InventorySize = new Vector2(4, 6);
    public float SlotSize;
    public Vector2 WindowSize;

    public bool CanDragItem = false;

	// Use this for initialization
	void Awake () {
        CreateSlots();
	}
	
	// Update is called once per frame
	void Update () {

        //마우스를 누를 때
        if (Input.GetMouseButtonDown(0) && SelectedItem != null)
        {
            CanDragItem = true;
            OriginalSlot = SelectedItem.parent;
            SelectedItem.GetComponent<Collider>().enabled = false;
            SetItemCollider(false);
        }

        //마우스 클릭 유지
        if (Input.GetMouseButton(0) && SelectedItem != null && CanDragItem)
        {
            SelectedItem.position = new Vector3(Camera.main.ScreenToWorldPoint(Input.mousePosition).x, Camera.main.ScreenToWorldPoint(Input.mousePosition).y, 0);
        }

        //마우스를 뗄 때
        else if(Input.GetMouseButtonUp(0) && SelectedItem != null)
        {
            CanDragItem = false;
            SetItemCollider(true);

            if (SelectedSlot == null)
                SelectedItem.parent = OriginalSlot;
            else
            {
                if(SelectedSlot.childCount > 0)
                {
                    //중복 아이템 겹치기
                    if (SelectedItem.name == SelectedSlot.GetChild(0).name &&
                    (SelectedItem.GetComponent<Item>().type == Item.Type.consumable || SelectedItem.GetComponent<Item>().type == Item.Type.misc))
                    {
                        Debug.Log("we stacked 2 items");
                        SelectedItem.GetComponent<Item>().IncreaseAmount(SelectedSlot.GetChild(0).GetComponent<Item>().amount);
                        Destroy(SelectedSlot.GetChild(0).gameObject);
                    }
                    //아이템 위치 교환
                    else
                    {
                        SelectedSlot.GetChild(0).SetParent(OriginalSlot);
                        foreach (Transform t in OriginalSlot)
                            t.localPosition = Vector3.zero;
                    }
                }
                SelectedItem.SetParent(SelectedSlot);
            }
            SelectedItem.localPosition = Vector3.zero;
            SelectedItem.GetComponent<Collider>().enabled = true;   
        }
	}

    void SetItemCollider(bool b)
    {
        foreach(GameObject item in GameObject.FindGameObjectsWithTag("Item"))
        {
            item.GetComponent<Collider>().enabled = b;
        }
    }
    public void ClearSlots()
    {
        foreach (Transform t in this.transform)
        {
            if(t.childCount > 0)
                Destroy(t.GetChild(0).gameObject);
        }
    }

    public void CreateSlots()
    {
        
        for (int y = 1; y <= InventorySize.y; y++)
        {
            for (int x = 1; x <= InventorySize.x; x++)
            {
                GameObject slot = Instantiate(SlotPrefab) as GameObject;
                RectTransform slotRect = slot.GetComponent<RectTransform>();
                slot.transform.SetParent(this.transform);
                slot.name = "slot_" + y + "_" + x;
                slot.GetComponent<RectTransform>().localPosition = new Vector3(WindowSize.x / (InventorySize.x + 1) * (x + 1), WindowSize.y / (InventorySize.y + 1) * -y, 0);
                slotRect.localScale = Vector3.one;
            }
        }
    }
    public void CreateInventory()
    {
        for(int n = 0; n < GameDB.sortedItems.Count; n++)
        {
            Item iData = GameDB.sortedItems[n];
            if(iData.coords != Vector2.zero)
            {
                GameObject item = Instantiate(ItemPrefab) as GameObject;
                item.name = iData.name;
                item.GetComponent<Image>().sprite = iData.sprite;
                item.transform.SetParent(transform.Find("slot_" + iData.coords.y + "_" + iData.coords.x));
                item.GetComponent<RectTransform>().localPosition = Vector3.zero;
                item.transform.localScale = Vector3.one;

                //Item Component Variables
                Item i = item.GetComponent<Item>();
                i.name = iData.name;
                i.type = iData.type;
                i.sprite = iData.sprite;
            }
        }

        {   
            //GameObject item = Instantiate(ItemPrefab) as GameObject;
            //item.transform.SetParent(slot.transform);
            //item.GetComponent<RectTransform>().localPosition = Vector3.zero;
            //Item i = item.GetComponent<Item>();
            //item.transform.localScale = Vector3.one;

            ////Item Component Variables
            //i.name = GameDB.sortedItems[(x + (y - 1) * 4) - 1].name;
            //i.type = GameDB.sortedItems[(x + (y - 1) * 4) - 1].type;
            //i.sprite = GameDB.sortedItems[(x + (y - 1) * 4) - 1].sprite;

            //item.name = i.name;
            //item.GetComponent<Image>().sprite = i.sprite;
        }    
    }
}
