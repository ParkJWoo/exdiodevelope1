﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameDB : MonoBehaviour {

    public Sprite[] sprites;

    public static GameDB _instance;

    public static List<Item> allItems = new List<Item>();
    public static List<Item> sortedItems = new List<Item>();

    // Use this for initialization
    void Awake () {

        _instance = this;

        //Item Creation
        Item i0 = gameObject.AddComponent<Item>();
        i0.name = "Key";
        i0.type = Item.Type.equip;
        i0.sprite = sprites[0];
        i0.coords = new Vector2(1, 1);
        allItems.Add(i0);

        Item i1 = gameObject.AddComponent<Item>();
        i1.name = "meat";
        i1.type = Item.Type.consumable;
        i1.sprite = sprites[1];
        i1.coords = new Vector2(2, 1);
        allItems.Add(i1);

        Item i2 = gameObject.AddComponent<Item>();
        i2.name = "shoe";
        i2.type = Item.Type.equip;
        i2.sprite = sprites[2];
        allItems.Add(i2);

        Item i3 = gameObject.AddComponent<Item>();
        i3.name = "bottle";
        i3.type = Item.Type.consumable;
        i3.sprite = sprites[3];
        allItems.Add(i3);

        Item i4 = gameObject.AddComponent<Item>();
        i4.name = "spray";
        i4.type = Item.Type.equip;
        i4.sprite = sprites[4];
        allItems.Add(i4);

        SortAllItems();
    }
	
    public void AddItem(Item item)
    {
        allItems.Add(item);
        SortAllItems();
    }

    public void SortAllItems()
    {
        sortedItems.Clear();
        foreach (Item i in allItems)
            sortedItems.Add(i);
    }
    public void SortItemsByType(string type)
    {
        sortedItems.Clear();
        foreach (Item i in allItems)
        {
            if (i.type.ToString() == type)
                sortedItems.Add(i);
        }
    }
}
