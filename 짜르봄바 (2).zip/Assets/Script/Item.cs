﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Item : MonoBehaviour {

    public new string name;
    public enum Type { equip, consumable, misc};
    public Type type;
    public int amount = 1;
    public Vector2 coords;

    public Sprite sprite;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnMouseEnter()
    {
        if(tag != "Loot")
        {
            transform.parent.parent.GetComponent<InventoryController>().SelectedItem = this.transform;
        }
    }
    void OnMouseExit()
    {
        if(tag != "Loot")
        {
            if (!transform.parent.parent.GetComponent<InventoryController>().CanDragItem)
                transform.parent.parent.GetComponent<InventoryController>().SelectedItem = null;
        }
        
    }
    public void IncreaseAmount(int a)
    {
        amount += a;
        transform.Find("Amount.text").GetComponent<Text>().text = amount.ToString();
    }
}
