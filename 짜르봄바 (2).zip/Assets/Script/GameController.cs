﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {

    public GameObject inventory, player;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKeyDown(KeyCode.I))
        {
            ToggleInventory();
        }
	}
    void ToggleInventory()
    {
        inventory.SetActive(!inventory.activeInHierarchy);
        if(inventory.activeInHierarchy)
            inventory.GetComponent<InventoryController>().CreateInventory();
        else
            inventory.GetComponent<InventoryController>().ClearSlots();
        Cursor.visible = inventory.activeInHierarchy;
        DisablePlayer(!inventory.activeInHierarchy);
    }
    void DisablePlayer(bool flag)
    {
        player.GetComponent<PlayerControl>().enabled = flag;
    }
}
