﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController2 : MonoBehaviour {

    public Inventory inventory;

	// Use this for initialization
	void Start () {
		
	}

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Item")
        {
            print("We picked item");
            inventory.AddItem(other.GetComponent<_Item>());
        }
    }
}
